from .. import Provider as DateTimeProvider


class Provider(DateTimeProvider):
    pass
